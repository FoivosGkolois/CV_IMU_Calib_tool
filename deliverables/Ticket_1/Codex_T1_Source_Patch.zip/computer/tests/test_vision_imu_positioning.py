from __future__ import annotations

import math
from dataclasses import replace

import pytest

from computer.vision_imu_calibration.geometry import KneeAngleResult
from computer.vision_imu_calibration.models import Landmark, LegLandmarks, LegSide
from computer.vision_imu_calibration.positioning import HIP_TARGET, PositioningCheck


def leg() -> LegLandmarks:
    def p(x, y):
        return Landmark(x, y, 0.9, 0.9)
    return LegLandmarks(LegSide.RIGHT, p(*HIP_TARGET), p(0.50, 0.50), p(0.65, 0.80))


def sweep(check, *, side_on=True, points=None, values=None):
    check.set_context(("camera", "fast", "none", "right", "right", 640, 480))
    check.begin(side_on)
    for i, value in enumerate(values or [175 - 85 * math.sin(math.pi * i / 30) for i in range(31)]):
        check.observe(i * 0.15, points or leg(), KneeAngleResult(value, True, 0.9, "ok"), 0.3)
    return check.finish(4.51)


def test_full_sweep_requires_manual_confirmation():
    assert sweep(PositioningCheck())["state"] == "PASSED"
    result = sweep(PositioningCheck(), side_on=False)
    assert result["state"] == "RETRY"
    assert "confirm" in result["reason"]


@pytest.mark.parametrize("values", [[130] * 31, [90 + 85 * i / 30 for i in range(31)]])
def test_still_or_one_way_motion_never_passes(values):
    assert sweep(PositioningCheck(), values=values)["state"] == "RETRY"


@pytest.mark.parametrize("field,value,reason", [
    ("ankle", Landmark(0.99, 0.8, 1, 1), "Ankle outside"),
    ("knee", Landmark(0.5, 0.5, 0.1, 1), "Knee confidence"),
    ("hip", Landmark(0.8, 0.22, 1, 1), "Hip away"),
    ("ankle", Landmark(float("nan"), 0.8, 1, 1), "finite"),
    ("knee", Landmark(0.5, 0.5, float("nan"), 1), "finite"),
])
def test_bad_observations_fail_the_whole_sweep(field, value, reason):
    result = sweep(PositioningCheck(), points=replace(leg(), **{field: value}))
    assert result["state"] == "RETRY"
    assert reason in result["reason"]


def test_dropout_latches_failure_and_does_not_hold_previous_frame():
    check = PositioningCheck()
    sweep(check)
    check.begin(True)
    check.observe(0, leg(), KneeAngleResult(175, True, 0.9, "ok"), 0.3)
    check.observe(0.1, None, KneeAngleResult(None, False, 0, "pose_missing"), 0.3)
    for i in range(1, 31):
        check.observe(i * .15, leg(), KneeAngleResult(175 - 85 * math.sin(math.pi * i / 30), True, .9, "ok"), .3)
    assert "pose_missing" in check.finish(4.51)["reason"]


@pytest.mark.parametrize("index,value", [(1, "quality"), (2, "clockwise_90"),
                                         (3, "left"), (4, "left"), (5, 1280)])
def test_pass_resets_when_setup_or_tracked_leg_changes(index, value):
    check = PositioningCheck()
    sweep(check)
    context = list(check.context)
    context[index] = value
    check.set_context(tuple(context))
    assert check.state == "READY"
    assert check.manual_side_on is False


def test_passed_guide_warns_without_cancelling_or_erasing_pass():
    check = PositioningCheck()
    sweep(check)
    check.observe(5, replace(leg(), hip=Landmark(.58, .22, 1, 1)), KneeAngleResult(150, True, 1, "ok"), .3)
    assert check.state == "PASSED"
    assert "shifted" in check.warning
    check.observe(6, None, KneeAngleResult(None, False, 0, "pose_missing"), .3)
    assert "invalid" in check.warning
    assert check.state == "PASSED"


def test_stale_camera_and_too_short_check_cannot_pass():
    check = PositioningCheck()
    check.begin(True)
    with pytest.raises(RuntimeError):
        PositioningCheck().finish(0)
    assert check.finish(4)["state"] == "RETRY"
    check = PositioningCheck()
    sweep(check)
    check.reset("restart")
    assert check.state != "PASSED"


@pytest.mark.parametrize("rotation", ["none", "clockwise_90", "counterclockwise_90", "rotate_180"])
def test_guides_align_with_the_rotated_inference_frame(rotation, monkeypatch):
    cv2 = pytest.importorskip("cv2")
    import numpy as np
    from computer.vision_imu_calibration.overlay import draw_leg_overlay, _pixel
    from computer.vision_imu_calibration.runtime import VisionRuntime
    from computer.vision_imu_calibration.tuning import FrameRotation
    frame = VisionRuntime._rotate_frame(np.zeros((240, 400, 3), dtype=np.uint8), FrameRotation(rotation), cv2)
    h, w = frame.shape[:2]
    result = draw_leg_overlay(frame, None, KneeAngleResult(None, False, 0, "pose_missing"),
                              inference_fps=0, source_description="test",
                              positioning={"enabled": True, "state": "READY"})
    x, y = _pixel(*HIP_TARGET, w, h)
    assert np.any(result[y, x])
    assert _pixel(.5, .22, w, h) == (round(.5 * (w - 1)), round(.22 * (h - 1)))


def test_blinded_overlay_keeps_skeleton_and_arc_but_removes_only_angle_text(monkeypatch):
    cv2 = pytest.importorskip("cv2")
    import numpy as np
    from computer.vision_imu_calibration.overlay import draw_leg_overlay
    labels = []
    original = cv2.putText
    def spy(frame, text, *args, **kwargs):
        labels.append(text)
        return original(frame, text, *args, **kwargs)
    monkeypatch.setattr(cv2, "putText", spy)
    frame = np.zeros((360, 480, 3), dtype=np.uint8)
    output = draw_leg_overlay(frame, leg(), KneeAngleResult(123, True, .9, "ok"),
                              inference_fps=15, source_description="test", hide_angle=True)
    assert "TRACKING VALID" in labels and "RIGHT" in labels
    assert not any("deg" in text for text in labels)
    assert np.any(output[100:])
