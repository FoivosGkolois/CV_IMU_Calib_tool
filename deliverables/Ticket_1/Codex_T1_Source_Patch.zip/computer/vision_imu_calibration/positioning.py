"""Cheap positioning checks on existing RAW landmarks in the rotated camera frame.

Defaults: 5% edge clearance, 10% hip target tolerance, 6% post-pass shift;
at least 3 s/15 frames with <=0.75 s gaps and an observed <=110..>=165 deg
sweep plus return (three alternating endpoints). These are positioning heuristics,
not anatomical orientation checks or guarantees about unobserved motion.
"""
from __future__ import annotations

import math

from .geometry import KneeAngleResult
from .models import LegLandmarks


HIP_TARGET = (0.5, 0.22)
SAFE_AREA = (0.05, 0.05, 0.95, 0.95)


def visibility_reason(leg: LegLandmarks | None, angle: KneeAngleResult,
                      confidence_threshold: float) -> str:
    if leg is None or not angle.valid or angle.angle_deg is None:
        return "Tracking invalid: " + angle.reason
    if not math.isfinite(angle.angle_deg) or not 0 <= angle.angle_deg <= 180:
        return "Nonfinite / out-of-range angle"
    for name in ("hip", "knee", "ankle"):
        point = getattr(leg, name)
        if not all(math.isfinite(v) for v in
                   (point.x, point.y, point.visibility, point.presence)):
            return f"{name.title()} is not a finite observation"
        if point.confidence < confidence_threshold:
            return f"{name.title()} confidence too low"
        if not (SAFE_AREA[0] <= point.x <= SAFE_AREA[2]
                and SAFE_AREA[1] <= point.y <= SAFE_AREA[3]):
            return f"{name.title()} outside safe area; move away from frame edge"
    return ""


class PositioningCheck:
    """Deterministic state; caller supplies time, observations and context."""

    def __init__(self) -> None:
        self.context: tuple | None = None
        self.enabled = False
        self.reset("Position Subject to begin")

    def reset(self, reason: str) -> None:
        self.state = "READY"
        self.reason = reason
        self.warning = ""
        self.manual_side_on = False
        self.count = 0
        self.first_time: float | None = None
        self.last_time: float | None = None
        self.minimum = math.inf
        self.maximum = -math.inf
        self.endpoints: list[str] = []
        self.failure = ""
        self.passed_hip: tuple[float, float] | None = None
        self.last_hip: tuple[float, float] | None = None

    def set_context(self, context: tuple) -> None:
        if self.context != context:
            self.context = context
            self.reset("Setup/tracked leg changed; repeat positioning check")

    def begin(self, manual_side_on: bool) -> None:
        self.enabled = True
        self.reset("Slowly flex and extend, then return; finish after the sweep")
        self.manual_side_on = manual_side_on is True
        self.state = "CHECKING"

    def observe(self, seconds: float, leg: LegLandmarks | None,
                angle: KneeAngleResult, confidence_threshold: float) -> None:
        if not self.enabled:
            return
        reason = visibility_reason(leg, angle, confidence_threshold)
        if self.state == "PASSED":
            self.warning = reason
            if not reason and leg is not None and self.passed_hip is not None:
                if math.dist((leg.hip.x, leg.hip.y), self.passed_hip) > 0.06:
                    self.warning = "Hip shifted; return to the floor mark / hip guide"
            return
        if self.state != "CHECKING":
            return
        if not math.isfinite(seconds):
            self.failure = self.failure or "Invalid sample timestamp; retry"
            return
        if self.last_time is not None and not 0 < seconds - self.last_time <= 0.75:
            self.failure = self.failure or "Camera samples interrupted; retry the sweep"
        if reason:
            self.failure = self.failure or reason
        if leg is not None and not reason:
            if math.dist((leg.hip.x, leg.hip.y), HIP_TARGET) > 0.10:
                self.failure = self.failure or "Hip away from target; reposition and retry"
            self.last_hip = (leg.hip.x, leg.hip.y)
            value = float(angle.angle_deg)
            self.minimum = min(self.minimum, value)
            self.maximum = max(self.maximum, value)
            endpoint = "flexed" if value <= 110 else "extended" if value >= 165 else ""
            if endpoint and (not self.endpoints or self.endpoints[-1] != endpoint):
                if len(self.endpoints) < 3:
                    self.endpoints.append(endpoint)
            self.count += 1
        if self.first_time is None:
            self.first_time = seconds
        self.last_time = seconds

    def finish(self, seconds: float) -> dict:
        if self.state != "CHECKING":
            raise RuntimeError("Start a positioning check first")
        reason = self.failure
        if not math.isfinite(seconds):
            reason = reason or "Invalid finish timestamp; retry"
        if self.last_time is None or seconds - self.last_time > 0.75:
            reason = reason or "No recent camera samples; retry"
        if self.count < 15 or self.first_time is None or self.last_time - self.first_time < 3:
            reason = reason or "Too short; sweep slowly for at least 3 seconds"
        if len(self.endpoints) < 3:
            reason = reason or "Incomplete observed sweep; flex to ~90, extend to ~175, and return"
        if not self.manual_side_on:
            reason = reason or "Operator must confirm side-on orientation manually"
        self.state = "RETRY" if reason else "PASSED"
        self.reason = reason or "Positioning Passed (observed sweep only)"
        if not reason:
            self.passed_hip = self.last_hip
        return self.snapshot()

    def snapshot(self) -> dict:
        return {"enabled": self.enabled, "state": self.state, "reason": self.reason,
                "warning": self.warning, "manual_side_on": self.manual_side_on,
                "frames": self.count, "hip_target": HIP_TARGET, "safe_area": SAFE_AREA,
                "observed_min_deg": self.minimum if math.isfinite(self.minimum) else None,
                "observed_max_deg": self.maximum if math.isfinite(self.maximum) else None}
